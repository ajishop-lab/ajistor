module.exports = {

  TELEGRAM_BOT_TOKEN: "8551203851:AAHqvBaCqrqH8_m-2FBu8yXcnonEB4oN1eM", // token bot tele lu
  OWNER_TELEGRAM_ID: 8969939880, // ada di database.json juga jangan lupa diganti yakk
  DEFAULT_OWNER_USERNAME: "reyy", // username owner buat login web
  DEFAULT_OWNER_PASSWORD: "123", // password owner buat login web (bisa diubah di sini)

  // URL Base dashboard website untuk menghasilkan tautan akses akun
  DASHBOARD_URL: "node2.zyrostore.id:3010", // ganti pake link panel + port 

  // WhatsApp API Server configuration
  WA_SERVER_PORT: 3010, // port panel
  WA_SERVER_URL: "node2.zyrostore.id:3010", // ini juga

  CREDITS: ["Vanness Wangsaff", "Baileys"] // ngehapus nama gw = error, ga percaya coba aja :v
};
